var express = require('express')
var router = express.Router()

router.get('/',function(req,res){
    // console.log(req)
    res.json({"Kim":"Hello World"})
})

router.get('/data' ,function(req,res){
    console.log(req)
    res.json({"address":"서울시 마포구 백범로 18"})
})  


router.get('/signup',function(req, res){
    res.render('signup')
})
module.exports = router;